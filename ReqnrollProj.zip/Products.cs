﻿namespace ReqnrollProject1
{
    public static class Products
    {
        public const string SEEDED_PRODUCTS = "SeededProducts";
        public const string PRODUCT_UNDER_TEST = "ProductUnderTest";

        //// holds the "database" of the products and quantities to populate the test
        //private static List<ProductQuantities>? _seededProducts;
        //// current product under test
        //private static ProductQuantities? _productUnderTest;

        public class ProductQuantities
        {
            public int ProductID { get; set; }
            public int Stock { get; set; }
            public int Basket { get; set; }
        }

        //public static List<ProductQuantities>? SeededProducts { get { return _seededProducts; } set { _seededProducts = value; } }

        //public static ProductQuantities? ProductUnderTest {  get { return _productUnderTest; } set { _productUnderTest = value; } }
    }
}
