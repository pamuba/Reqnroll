﻿namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_Then
    {
        ScenarioContext _scenarioContext;
        public Steps_Then(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Then("the quantities are")]
        public void ThenTheQuantitiesAre(DataTable dataTable)
        {
            //dataTable.CompareToInstance(_productUnderTest);
            var products = _scenarioContext.Get<List<Products.ProductQuantities>>(Products.SEEDED_PRODUCTS);
            dataTable.CompareToSet(products);
        }

        [Then("the quantities are stock level of {int} and basket qty of {int}")]
        public void ThenTheQuantitiesAreStockLevelOfAndBasketQtyOf(int stockQty, int basketQty)
        {
            var productUnderTest = _scenarioContext.Get<Products.ProductQuantities>(Products.PRODUCT_UNDER_TEST);

            Assert.AreEqual(stockQty, productUnderTest.Stock);
            Assert.AreEqual(basketQty, productUnderTest.Basket);
        }

        [Then("a message {string} is displayed to the customer")]
        public void ThenAMessageIsDisplayedToTheCustomer(string p0)
        {
            //_scenarioContext.Pending();
        }

    }
}
