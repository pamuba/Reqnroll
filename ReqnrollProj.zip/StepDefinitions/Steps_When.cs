﻿namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_When
    {
        ScenarioContext _scenarioContext;
        public Steps_When(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [When("I click the Add to Basket button")]
        public void WhenIClickTheAddToBasketButton()
        {
            var productUnderTest = _scenarioContext.Get<Products.ProductQuantities>(Products.PRODUCT_UNDER_TEST);

            if (productUnderTest.Stock > 0 && productUnderTest.Basket == 0)
            {
                productUnderTest.Stock--;
                productUnderTest.Basket++;
            }
        }

        [When("I remove Product Id {int} from basket")]
        public void WhenIRemoveProductIdFromBasket(int productID)
        {
            var products = _scenarioContext.Get<List<Products.ProductQuantities>>(Products.SEEDED_PRODUCTS);
            var product = products.FirstOrDefault(p => p.ProductID == productID);
            if (product == null) throw new ArgumentNullException(nameof(product));

            product.Basket--;
            product.Stock++;
        }

    }
}
