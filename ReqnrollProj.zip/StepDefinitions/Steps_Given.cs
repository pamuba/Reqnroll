﻿namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_Given
    {
        ScenarioContext _scenarioContext;
        public Steps_Given(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;   
        }

        [Given("I have the following data")]
        public void GivenIHaveTheFollowingData(DataTable dataTable)
        {
            _scenarioContext.Add(Products.SEEDED_PRODUCTS, dataTable.CreateSet<Products.ProductQuantities>().ToList());
        }

        [Given("I am on the product detail page of product {int}")]
        public void GivenIAmOnTheProductDetailPageOfProduct(int productID)
        {
            var products = _scenarioContext.Get<List<Products.ProductQuantities>>(Products.SEEDED_PRODUCTS);
            var productUnderTest = products.FirstOrDefault(p => p.ProductID == productID);
            if (productUnderTest == null) throw new ArgumentNullException(nameof(productUnderTest));

            _scenarioContext.Add(Products.PRODUCT_UNDER_TEST, productUnderTest);
        }


        [Given("I am on the basket page")]
        public void GivenIAmOnTheBasketPage()
        {

        }
    }
}
