﻿namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_Then : ContextHelper
    {

        [Then("the quantities are")]
        public void ThenTheQuantitiesAre(DataTable dataTable)
        {
            //dataTable.CompareToInstance(_productUnderTest);
            dataTable.CompareToSet(ProductContext.SeededProducts);
        }

        [Then("the quantities are stock level of {int} and basket qty of {int}")]
        public void ThenTheQuantitiesAreStockLevelOfAndBasketQtyOf(int stockQty, int basketQty)
        {  
            var productUnderTest = ProductContext.ProductUnderTest;
            Assert.AreEqual(stockQty, productUnderTest?.Stock);
            Assert.AreEqual(basketQty, productUnderTest?.Basket);
        }

        [Then("a message {string} is displayed to the customer")]
        public void ThenAMessageIsDisplayedToTheCustomer(string p0)
        {
            //_scenarioContext.Pending();
        }

    }
}
