﻿using static ReqnrollProject1.Products;

namespace ReqnrollProject1
{
    public class ContextHelper : Steps
    {
        protected ProductTestDataContext ProductContext
        {
            get
            {
                return ScenarioContext.ScenarioContainer.Resolve<ProductTestDataContext>();

            }
        }

        // Customer Context

        // Basket Context

        // Category Context
    }
}
