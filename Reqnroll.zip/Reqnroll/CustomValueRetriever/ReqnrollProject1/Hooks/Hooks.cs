﻿


using System.Diagnostics;
using Reqnroll.Assist;

namespace ReqnrollProject1.Hooks
{
    [Binding]
    public sealed class Hooks
    {
        private IReqnrollOutputHelper _outputHelper;

        public Hooks(IReqnrollOutputHelper outputHelper)
        {
            _outputHelper = outputHelper;
        }

        [BeforeTestRun]
        public static void BeforeTestRun()
        {
           Service.Instance.ValueRetrievers.Register(new ClothesSizeRetriever());
        }

        [AfterTestRun]
        public static void AfterTestRun()
        {
           Service.Instance.ValueRetrievers.Unregister(new ClothesSizeRetriever());

        }

        [BeforeFeature]
        public static void BeforeFeature(FeatureContext featureContext)
        {
            Debug.WriteLine($"Before Feature: Title:{featureContext.FeatureInfo.Title} Desc:{featureContext.FeatureInfo.Description}");
            // TODO: start browser instance
        }

        [AfterFeature]
        public static void AfterFeature(FeatureContext featureContext)
        {
            Debug.WriteLine($"After Feature: Title:{featureContext.FeatureInfo.Title} Desc:{featureContext.FeatureInfo.Description}");
            // TODO: close browser instance
        }
        

        [BeforeScenario]
        public void BeforeScenario(ScenarioContext scenarioContext)
        {
            _outputHelper.WriteLine($"Before Scenario: Title: {scenarioContext.ScenarioInfo.Title}");

        }

   

        [AfterScenario]
        public void AfterScenario(ScenarioContext scenarioContext)
        {
            _outputHelper.WriteLine($"After Scenario: Title: {scenarioContext.ScenarioInfo.Title}");
        }

        [BeforeScenarioBlock]
        public void BeforeScenarioBlock()
        {
            _outputHelper.WriteLine(nameof(BeforeScenarioBlock));
        }

        [AfterScenarioBlock]
        public void AfterScenarioBlock()
        {
            _outputHelper.WriteLine(nameof(AfterScenarioBlock));
        }

        [BeforeStep]
        public void BeforeStep(ScenarioContext scenarioContext)
        {
            _outputHelper.WriteLine($"Before Step: {scenarioContext.StepContext.StepInfo.Text} Type: {scenarioContext.StepContext.StepInfo.StepDefinitionType}");
            // TODO: use reqnoll logging api to output the step
        }

        [AfterStep]
        public void AfterStep()
        {
            _outputHelper.WriteLine(nameof( AfterStep));   
        }



    }
}
