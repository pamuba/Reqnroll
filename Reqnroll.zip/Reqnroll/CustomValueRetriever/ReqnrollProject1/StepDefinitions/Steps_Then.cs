﻿using static ReqnrollProject1.Models;

namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_Then
    {
        private ProductTestDataContext _productTestDataContext;

        public Steps_Then(ProductTestDataContext productTestDataContext)
        {
            _productTestDataContext = productTestDataContext;
        }

        [Then("the quantities are")]
        public void ThenTheQuantitiesAre(DataTable dataTable)
        {
            //dataTable.CompareToInstance(_productUnderTest);
            dataTable.CompareToSet(_productTestDataContext.SeededProducts);
        }

        [Then("the quantities are stock level of {int} and basket qty of {int}")]
        public void ThenTheQuantitiesAreStockLevelOfAndBasketQtyOf(int stockQty, int basketQty)
        {  
            var productUnderTest = _productTestDataContext.ProductUnderTest;
            Assert.AreEqual(stockQty, productUnderTest?.Stock);
            Assert.AreEqual(basketQty, productUnderTest?.Basket);
        }

        [Then("a message {string} is displayed to the customer")]
        public void ThenAMessageIsDisplayedToTheCustomer(string p0)
        {
            //_scenarioContext.Pending();
        }

        [Then("the offer code is valid")]
        public void ThenTheOfferCodeIsValid()
        {
           
        }


    }
}
