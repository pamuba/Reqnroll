﻿using static ReqnrollProject1.Models;

namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_Given
    {
        private ProductTestDataContext _productTestDataContext;

        public Steps_Given(ProductTestDataContext productTestDataContext)
        {
            _productTestDataContext = productTestDataContext;
        }

        [Given("I have the following data")]
        public void GivenIHaveTheFollowingData(DataTable dataTable)
        {
            _productTestDataContext.SeededProducts = dataTable.CreateSet<Models.ProductQuantities>().ToList();
        }

        [Given("I am on the product detail page of product {int}")]
        public void GivenIAmOnTheProductDetailPageOfProduct(int productID)
        {
            _productTestDataContext.ProductUnderTest = _productTestDataContext.SeededProducts?.FirstOrDefault(p => p.ProductID == productID);
            if (_productTestDataContext.ProductUnderTest == null) throw new ArgumentNullException(nameof(_productTestDataContext.ProductUnderTest));
        }


        [Given("I am on the basket page")]
        public void GivenIAmOnTheBasketPage()
        {

        }

        [Given("I have an offer code of {string} with an offer type of {OfferCodeType}")]
        public void GivenIHaveAnOfferCodeOfWithAnOfferTypeOf(string offerCode, OfferCodeType offerCodeType)
        {
            
        }


        [Given("today is {DateTime}")]
        public void GivenTodayIs(DateTime today)
        {
            
        }

        [Given("I have the following offer codes")]
        public void GivenIHaveTheFollowingOfferCodes(DataTable dataTable)
        {
            var result = dataTable.CreateSet<OfferCodes>();
        }

        [Given("I have the following clothes size data")]
        public void GivenIHaveTheFollowingClothesSizeData(DataTable dataTable)
        {
            var result = dataTable.CreateSet<Models.ClothesSize>();
        }


    }
}
