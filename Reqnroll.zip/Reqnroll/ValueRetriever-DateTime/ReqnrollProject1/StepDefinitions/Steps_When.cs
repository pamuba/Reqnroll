﻿using static ReqnrollProject1.Products;

namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_When
    {
        private ProductTestDataContext _productTestDataContext;

        public Steps_When(ProductTestDataContext productTestDataContext)
        {
            _productTestDataContext = productTestDataContext;
        }

        [When("I click the Add to Basket button")]
        public void WhenIClickTheAddToBasketButton()
        {
            var productUnderTest = _productTestDataContext.ProductUnderTest;

            if (productUnderTest?.Stock > 0 && productUnderTest?.Basket == 0)
            {
                productUnderTest.Stock--;
                productUnderTest.Basket++;
            }
        }

        [When("I remove Product Id {int} from basket")]
        public void WhenIRemoveProductIdFromBasket(int productID)
        {
            _productTestDataContext.ProductUnderTest = _productTestDataContext.SeededProducts?.FirstOrDefault(p => p.ProductID == productID);
            if (_productTestDataContext.ProductUnderTest == null) throw new ArgumentNullException(nameof(_productTestDataContext.ProductUnderTest));

            _productTestDataContext.ProductUnderTest.Basket--;
            _productTestDataContext.ProductUnderTest.Stock++;
        }

        [When("I add offer code {string} to the basket")]
        public void WhenIAddOfferCodeToTheBasket(string p0)
        {
           
        }

    }
}
