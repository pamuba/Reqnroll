﻿namespace ReqnrollProject1
{
    public class Models
    {
        public const string PRODUCT_TEST_DATA_CONTEXT = "ProductTestDataContext";

        public class ProductQuantities
        {
            public int ProductID { get; set; }
            public int Stock { get; set; }
            public int Basket { get; set; }
        }

        public class ProductTestDataContext
        {
            public List<ProductQuantities>? SeededProducts;
            public ProductQuantities? ProductUnderTest;
        }

        public class OfferCodeContext
        {
            public List<OfferCodes>? OfferCodes;
            public DateTime Today;
        }

        public class OfferCodes
        {
            public string OfferCode { get; set; }
            public DateTime ExpiryDate { get; set; }
            public OfferCodeType OfferCodeType { get; set; }
        }

        public enum OfferCodeType
        {
            ByProduct,
            ByDate,
            ByPrice,
            ByDay
        }

    }
}
