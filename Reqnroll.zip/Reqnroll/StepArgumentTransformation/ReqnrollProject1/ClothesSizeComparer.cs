﻿using Reqnroll.Assist;

namespace ReqnrollProject1
{
    public class ClothesSizeComparer : IValueComparer
    {
        public bool CanCompare(object actualValue)
        {
            return actualValue is Models.InternalSize;
        }

        public bool Compare(string expectedValue, object actualValue)
        {
            return (actualValue as Models.InternalSize).InternalName.Equals(expectedValue);
        }
    }
}
