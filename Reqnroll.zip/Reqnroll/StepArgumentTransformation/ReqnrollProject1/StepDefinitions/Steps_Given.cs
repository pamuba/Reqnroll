﻿using Reqnroll.Assist.Dynamic;
using static ReqnrollProject1.Models;

namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_Given
    {
        private ProductTestDataContext _productTestDataContext;
        private ClothesSizeContext _clothesSizeContext;

        public Steps_Given(ProductTestDataContext productTestDataContext, ClothesSizeContext clothesSizeContext)
        {
            _productTestDataContext = productTestDataContext;
            _clothesSizeContext = clothesSizeContext;
        }

        [Given("I have the following data")]
        public void GivenIHaveTheFollowingData(DataTable dataTable)
        {
            _productTestDataContext.SeededProducts = dataTable.CreateSet<Models.ProductQuantities>().ToList();
        }

        [Given("I am on the product detail page of product {int}")]
        public void GivenIAmOnTheProductDetailPageOfProduct(int productID)
        {
            _productTestDataContext.ProductUnderTest = _productTestDataContext.SeededProducts?.FirstOrDefault(p => p.ProductID == productID);
            if (_productTestDataContext.ProductUnderTest == null) throw new ArgumentNullException(nameof(_productTestDataContext.ProductUnderTest));
        }


        [Given("I am on the basket page")]
        public void GivenIAmOnTheBasketPage()
        {

        }

        [Given("I have an offer code of {string} with an offer type of {OfferCodeType}")]
        public void GivenIHaveAnOfferCodeOfWithAnOfferTypeOf(string offerCode, OfferCodeType offerCodeType)
        {
            
        }


        [Given("today is {DateTime}")]
        public void GivenTodayIs(DateTime today)
        {
            
        }

        [Given("I have offer code {string} which expires in {string}")]
        [Given("I have offer code {string} which expires {string}")]
        public void GivenIHaveOfferCodeWhichExpiresIn(string offerCode, DateTime expiryDate)
        {
            
        }



        [Given("I have the following offer codes")]
        public void GivenIHaveTheFollowingOfferCodes(DataTable dataTable)
        {
            var result = dataTable.CreateSet<OfferCodes>();
        }

        [Given("I have the following clothes size data")]
        public void GivenIHaveTheFollowingClothesSizeData(DataTable dataTable)
        {
            _clothesSizeContext.ClothesSize = dataTable.CreateSet<Models.ClothesSize>().ToList();
        }

        [Given("I have the following stores")]
        public void GivenIHaveTheFollowingStores(DataTable dataTable)
        {
            //var result = dataTable.CreateSet<Models.Stores>().ToList();
            var result = dataTable.CreateDynamicSet();

            var stores = new List<Models.Stores>();
            foreach (var entry in result)
            {
                var store = new Models.Stores();
                store.StoreName = entry.StoreName.ToUpper();

                var coords = entry.GeoLocation.Split(",");

                store.GeoLocation = new GeoLocation {  Longitude = coords[0], Latitude = coords[1] };
                stores.Add(store);
            }
        }


    }
}
