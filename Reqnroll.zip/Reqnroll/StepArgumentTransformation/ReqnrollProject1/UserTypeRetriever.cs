﻿using Reqnroll.Assist;

namespace ReqnrollProject1
{
    public class UserTypeRetriever : IValueRetriever
    {
        public bool CanRetrieve(KeyValuePair<string, string> keyValuePair, Type targetType, Type propertyType)
        {
            return propertyType == typeof(Models.User);
        }

        public object Retrieve(KeyValuePair<string, string> keyValuePair, Type targetType, Type propertyType)
        {
            var value = (Models.UserTypeEnum)Enum.Parse(typeof(Models.UserTypeEnum), keyValuePair.Value);

            return new Models.User {  UserType = value, AccessLevel = (int)value };
        }
    }
}
