﻿using Reqnroll.Assist;

namespace ReqnrollProject1
{
    public class ClothesSizeRetriever : IValueRetriever
    {
        public bool CanRetrieve(KeyValuePair<string, string> keyValuePair, Type targetType, Type propertyType)
        {    
           return propertyType == typeof(Models.InternalSize);
        }

        public object Retrieve(KeyValuePair<string, string> keyValuePair, Type targetType, Type propertyType)
        {
            switch (keyValuePair.Value)
            {
                case "XXL":
                    return new Models.InternalSize { InternalName = "ExtraExtraLarge", Width = "240cm", Height = "240cm" };
                case "L":
                    return new Models.InternalSize { InternalName = "Large", Width = "200cm", Height = "200cm" };
                case "S":
                    return new Models.InternalSize { InternalName = "Small", Width = "140cm", Height = "140cm" };
                default:
                    return new Models.InternalSize { InternalName = "Unknown" };
            }
        }
    }
}
