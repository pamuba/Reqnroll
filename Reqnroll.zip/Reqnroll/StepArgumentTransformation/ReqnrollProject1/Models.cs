﻿namespace ReqnrollProject1
{
    public class Models
    {
        public const string PRODUCT_TEST_DATA_CONTEXT = "ProductTestDataContext";

        public class ProductQuantities
        {
            public int ProductID { get; set; }
            public int Stock { get; set; }
            public int Basket { get; set; }
        }

        public class ProductTestDataContext
        {
            public List<ProductQuantities>? SeededProducts;
            public ProductQuantities? ProductUnderTest;
        }

        public class OfferCodeContext
        {
            public List<OfferCodes>? OfferCodes;
            public DateTime Today;
        }

        public class ClothesSizeContext
        {
            public List<ClothesSize>? ClothesSize;
        }

        public class OfferCodes
        {
            public string OfferCode { get; set; }
            public DateTime ExpiryDate { get; set; }
            public OfferCodeType OfferCodeType { get; set; }
            public bool IsValid { get; set; }
        }

        public enum OfferCodeType
        {
            ByProduct,
            ByDate,
            ByPrice,
            ByDay
        }

        public class ClothesSize
        {
            public string Name { get; set; }
            public InternalSize Size { get; set; }
        }
       
        public class InternalSize
        {
            public string InternalName { get; set; }
            public string Width { get; set; }
            public string Height { get; set; }
        }

        public enum UserTypeEnum
        {
            Supervisor,
            Staff,
            Customer,
            Visitor
        }

        public class Stores
        {
            public string StoreName { get; set; }
            public GeoLocation GeoLocation { get; set; }
        }

        public class GeoLocation
        {
            public string Longitude { get; set; }
            public string Latitude { get; set; }
        }

        public class Users
        {
            public string Name { get; set; }
            public DateTime? LoggedInDate { get; set; }
        }

        public class User
        {
            public int AccessLevel { get; set; }
            public UserTypeEnum UserType { get; set; }
        }
    }
}
