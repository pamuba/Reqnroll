﻿namespace ReqnrollProject1
{
    [Binding]
    public class StepTransformation
    {
        [StepArgumentTransformation(@"(\d+) days ago")]
        public DateTime DaysAgo(int daysAgo)
        {
            return DateTime.Today.AddDays(-daysAgo);
        }

        [StepArgumentTransformation(@"(\d+) days time")]
        public DateTime InDaysTime(int daysTime)
        {
            return DateTime.Today.AddDays(daysTime);
        }
    }
}
