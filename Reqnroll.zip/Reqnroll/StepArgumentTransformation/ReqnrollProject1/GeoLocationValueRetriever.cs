﻿using Reqnroll.Assist;

namespace ReqnrollProject1
{
    public class GeoLocationValueRetriever : IValueRetriever
    {
        public bool CanRetrieve(KeyValuePair<string, string> keyValuePair, Type targetType, Type propertyType)
        {
            return propertyType == typeof(Models.GeoLocation);
        }

        public object Retrieve(KeyValuePair<string, string> keyValuePair, Type targetType, Type propertyType)
        {
            Models.GeoLocation geoLocation = new Models.GeoLocation();

            var coords = keyValuePair.Value.Split(",");
            geoLocation.Latitude = coords[0];
            geoLocation.Longitude = coords[1];

            return geoLocation;
        }
    }
}
