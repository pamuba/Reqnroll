﻿namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_Then
    {
        private ScenarioContext _scenarioContext;
        public Steps_Then(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Then("the quantities are")]
        public void ThenTheQuantitiesAre(DataTable dataTable)
        {
            //dataTable.CompareToInstance(_productUnderTest);
            var productTestDataContext = _scenarioContext.Get<Products.ProductTestDataContext>(Products.PRODUCT_TEST_DATA_CONTEXT);
            var products = productTestDataContext.SeededProducts;
            dataTable.CompareToSet(products);
        }

        [Then("the quantities are stock level of {int} and basket qty of {int}")]
        public void ThenTheQuantitiesAreStockLevelOfAndBasketQtyOf(int stockQty, int basketQty)
        {
            var productTestDataContext = _scenarioContext.Get<Products.ProductTestDataContext>(Products.PRODUCT_TEST_DATA_CONTEXT);
            var productUnderTest = productTestDataContext.ProductUnderTest;
            Assert.AreEqual(stockQty, productUnderTest?.Stock);
            Assert.AreEqual(basketQty, productUnderTest?.Basket);
        }

        [Then("a message {string} is displayed to the customer")]
        public void ThenAMessageIsDisplayedToTheCustomer(string p0)
        {
            //_scenarioContext.Pending();
        }

    }
}
