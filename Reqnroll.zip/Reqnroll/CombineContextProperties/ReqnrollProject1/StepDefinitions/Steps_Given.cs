﻿namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_Given
    {
        private ScenarioContext _scenarioContext;
        public Steps_Given(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [Given("I have the following data")]
        public void GivenIHaveTheFollowingData(DataTable dataTable)
        {
            var productTestDataContext = new Products.ProductTestDataContext();
            productTestDataContext.SeededProducts = dataTable.CreateSet<Products.ProductQuantities>().ToList();
            _scenarioContext.Add(Products.PRODUCT_TEST_DATA_CONTEXT, productTestDataContext);
        }

        [Given("I am on the product detail page of product {int}")]
        public void GivenIAmOnTheProductDetailPageOfProduct(int productID)
        {
            var productTestDataContext = _scenarioContext.Get<Products.ProductTestDataContext>(Products.PRODUCT_TEST_DATA_CONTEXT);
            var products = productTestDataContext.SeededProducts;
            productTestDataContext.ProductUnderTest = products?.FirstOrDefault(p => p.ProductID == productID);
            if (productTestDataContext.ProductUnderTest == null) throw new ArgumentNullException(nameof(productTestDataContext.ProductUnderTest));
        }


        [Given("I am on the basket page")]
        public void GivenIAmOnTheBasketPage()
        {

        }
    }
}
