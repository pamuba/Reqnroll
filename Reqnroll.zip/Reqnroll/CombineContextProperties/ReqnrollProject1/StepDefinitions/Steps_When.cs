﻿namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_When
    {
        private ScenarioContext _scenarioContext;
        public Steps_When(ScenarioContext scenarioContext)
        {
            _scenarioContext = scenarioContext;
        }

        [When("I click the Add to Basket button")]
        public void WhenIClickTheAddToBasketButton()
        {
            var productTestDataContext = _scenarioContext.Get<Products.ProductTestDataContext>(Products.PRODUCT_TEST_DATA_CONTEXT);
            var productUnderTest = productTestDataContext.ProductUnderTest;

            if (productUnderTest?.Stock > 0 && productUnderTest?.Basket == 0)
            {
                productUnderTest.Stock--;
                productUnderTest.Basket++;
            }
        }

        [When("I remove Product Id {int} from basket")]
        public void WhenIRemoveProductIdFromBasket(int productID)
        {
            var productTestDataContext = _scenarioContext.Get<Products.ProductTestDataContext>(Products.PRODUCT_TEST_DATA_CONTEXT);
            var products = productTestDataContext.SeededProducts;
            var product = products?.FirstOrDefault(p => p.ProductID == productID);
            if (product == null) throw new ArgumentNullException(nameof(product));

            product.Basket--;
            product.Stock++;
        }

    }
}
