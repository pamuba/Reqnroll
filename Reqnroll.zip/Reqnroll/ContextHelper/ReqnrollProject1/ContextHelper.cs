﻿using static ReqnrollProject1.Products;

namespace ReqnrollProject1
{
    public class ContextHelper : Steps
    {
        protected ProductTestDataContext ProductContext
        {
            get
            {
                var productTestDataContext = new ProductTestDataContext();

                if (ScenarioContext.ContainsKey(PRODUCT_TEST_DATA_CONTEXT) == false)
                {
                    productTestDataContext.SeededProducts = new List<ProductQuantities>();
                    ScenarioContext.Add(PRODUCT_TEST_DATA_CONTEXT, productTestDataContext);
                }
                else
                {
                    productTestDataContext = ScenarioContext.Get<ProductTestDataContext>(PRODUCT_TEST_DATA_CONTEXT);
                }

                return productTestDataContext;
            }
        }

        // Customer Context

        // Basket Context

        // Category Context
    }
}
