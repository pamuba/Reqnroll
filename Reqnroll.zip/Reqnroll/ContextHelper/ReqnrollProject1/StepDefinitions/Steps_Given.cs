﻿namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_Given : ContextHelper
    {
        [Given("I have the following data")]
        public void GivenIHaveTheFollowingData(DataTable dataTable)
        {
            ProductContext.SeededProducts = dataTable.CreateSet<Products.ProductQuantities>().ToList();
        }

        [Given("I am on the product detail page of product {int}")]
        public void GivenIAmOnTheProductDetailPageOfProduct(int productID)
        {
            ProductContext.ProductUnderTest = ProductContext.SeededProducts?.FirstOrDefault(p => p.ProductID == productID);
            if (ProductContext.ProductUnderTest == null) throw new ArgumentNullException(nameof(ProductContext.ProductUnderTest));
        }


        [Given("I am on the basket page")]
        public void GivenIAmOnTheBasketPage()
        {

        }
    }
}
