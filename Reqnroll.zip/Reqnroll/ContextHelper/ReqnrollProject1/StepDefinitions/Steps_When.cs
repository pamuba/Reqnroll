﻿namespace ReqnrollProject1.StepDefinitions
{
    [Binding]
    public sealed class Steps_When : ContextHelper
    {
        [When("I click the Add to Basket button")]
        public void WhenIClickTheAddToBasketButton()
        {
            var productUnderTest = ProductContext.ProductUnderTest;

            if (productUnderTest?.Stock > 0 && productUnderTest?.Basket == 0)
            {
                productUnderTest.Stock--;
                productUnderTest.Basket++;
            }
        }

        [When("I remove Product Id {int} from basket")]
        public void WhenIRemoveProductIdFromBasket(int productID)
        {
            ProductContext.ProductUnderTest = ProductContext.SeededProducts?.FirstOrDefault(p => p.ProductID == productID);
            if (ProductContext.ProductUnderTest == null) throw new ArgumentNullException(nameof(ProductContext.ProductUnderTest));

            ProductContext.ProductUnderTest.Basket--;
            ProductContext.ProductUnderTest.Stock++;
        }

    }
}
